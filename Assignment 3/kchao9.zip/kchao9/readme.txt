cd assignment3

python Kmeans.py
python Kmeans-wine.py

python Expectation Maximization.py

python Expectation Maximization-wine.py

python FactorAnalysis.py
python FactorAnalysis-wine.py
python ICA.py
python ICA-wine.py
python PCA.py
python PCA-wine.py

python Randomized projection-wine.py
python Randomized projection.py